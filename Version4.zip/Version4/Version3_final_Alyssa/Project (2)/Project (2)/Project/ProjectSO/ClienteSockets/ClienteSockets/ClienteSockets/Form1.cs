﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Threading;
using System.Reflection.Emit;

namespace ClienteSockets
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread Atender;
        int conectado = 0;//Para saber si estamos conectados al servidor o no
        int login = 0;//Para saber si el usuario ha iniciado sesión

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private void AtenderServidor()
        {
            while (true)
            {
                byte[] msg = new byte[80];
                server.Receive(msg);
                string[] trozos = Encoding.ASCII.GetString(msg).Split('/');
                int codigo = Convert.ToInt32(trozos[0]);
                string mensaje = trozos[1].Split('\0')[0];
                switch (codigo)
                {
                    case 0://registrarse
                        if (mensaje == "Registro exitoso.")
                        {
                            MessageBox.Show("Te has registrado con éxito.");

                            // ** AQUÍ forzamos el login automático tras registrarnos con éxito **

                            // Construimos el mensaje de login
                            string loginMsg = "9/" + Username2TextBox.Text + "/" + Password2TextBox.Text;
                            byte[] loginBytes = Encoding.ASCII.GetBytes(loginMsg);
                            server.Send(loginBytes);
                        }
                        else
                        {
                            MessageBox.Show("Error en el registro");
                        }
                        break;
                    case 1: //saber el numero da partidas jugadas
                        MessageBox.Show(mensaje);
                        break;
                    case 2: //saber la puntuaction maxima
                        MessageBox.Show(mensaje);
                        break;
                    case 3: //saber los jugadores con partidas
                        MessageBox.Show(mensaje);
                        break;
                    case 8: //recibir la notificacion de la lista de usuarios
                        // Esperamos algo como "Juan,Maria,Pedro"
                        string[] usuarios = mensaje.Split(',');

                        listBoxUsuarios.Items.Clear();
                        foreach (string usuario in usuarios)
                        {
                            listBoxUsuarios.Items.Add(usuario.Trim());
                        }
                        break;
                    case 9: //login
                        if (mensaje == "Login exitoso.")
                        {
                            MessageBox.Show("Has inciado sesión con éxito.");
                            this.login = 1;
                        }
                        else if (mensaje == "Usuario o contraseña incorrectos.")
                        {
                            MessageBox.Show("El nombre de usuario o contraseña son incorrectos.");
                        }
                        else if (mensaje == "Error en la consulta.")
                        {
                            MessageBox.Show("Ha ocurrido un error en la consulta.");
                        }
                        break;
                    case 4: // Invitación entrante
                        DialogResult result = MessageBox.Show(
                            $"Has recibido una invitación de {mensaje}. ¿Deseas aceptar?",
                            "Invitación de juego",
                            MessageBoxButtons.YesNo);

                        string respuestaInvitacion = result == DialogResult.Yes
                            ? $"5/{mensaje}/ACEPTADA"
                            : $"5/{mensaje}/RECHAZADA";
                        byte[] respBytes = Encoding.ASCII.GetBytes(respuestaInvitacion);
                        server.Send(respBytes);
                        break;
                    case 5: // Respuesta a la invitación
                        MessageBox.Show($"Respuesta a tu invitación: {mensaje}");
                        break;



                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Definimos la dirección y el puerto del servidor
                IPAddress ip = IPAddress.Parse("10.4.119.5");
                IPEndPoint ipep = new IPEndPoint(ip, 50001);

                // Creamos el socket TCP
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                // Intentamos conectar
                server.Connect(ipep);

                // Cambiamos el fondo a verde para indicar conexión exitosa
                this.BackColor = System.Drawing.Color.Green;
                this.conectado = 1;
                MessageBox.Show("Conectado al servidor");


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con el servidor: " + ex.Message);
            }

            ThreadStart ts = delegate { AtenderServidor(); };
            Atender = new Thread(ts);
            Atender.Start();
        }

        private void buttonLogIn_Click(object sender, EventArgs e)
        {
            if (this.conectado == 1)
            {
                if (Username1TextBox.Text == null || Password1TextBox.Text == null)
                {
                    MessageBox.Show("No puedes realizar el inicio de sesion sin haber puesto un nombre de usuario o contraseña!");
                }
                else
                {
                    string mensaje = "9/" + Username1TextBox.Text + "/" + Password1TextBox.Text;
                    //Enviamos al servidor el nombre y contraseña tecleados
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
            }
            else
            {
                MessageBox.Show("¡Antes de poder realizar cualquier acción debes conectarte al servidor!");
            }
        }

        public int GetConectado()
        {
            return this.conectado;
        }

        public int GetLogin()
        {
            return this.login;
        }

        private void Password1TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            if (this.conectado == 1)
            {
                // Comprobamos que se haya introducido usuario y contraseña
                if (string.IsNullOrEmpty(Username2TextBox.Text) || string.IsNullOrEmpty(Password2TextBox.Text))
                {
                    MessageBox.Show("No puedes registrarte sin haber puesto un nombre de usuario o contraseña!");
                    return;
                }
                else
                {
                    // Enviamos petición de registro al servidor
                    string mensaje = "0/" + Username2TextBox.Text + "/" + Password2TextBox.Text;
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                }
            }
            else
            {
                MessageBox.Show("¡Antes de poder realizar cualquier acción debes conectarte al servidor!");
            }
        }


        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.conectado == 1)
            {
                // Cierra la conexión con el servidor
                server.Shutdown(SocketShutdown.Both);
                server.Close();

                // Cambiamos el estado y, si quieres, el color de fondo
                this.conectado = 0;
                this.login = 0; // por si quieres forzar a que el usuario vuelva a loguearse al reconectar
                Atender.Abort();
                this.BackColor = System.Drawing.Color.Gray;

                listBoxUsuarios.Items.Clear();
                MessageBox.Show("Desconectado del servidor.");
            }
            else
            {
                MessageBox.Show("No estás conectado al servidor.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void SendQuery(string queryType)
        {
            try
            {
                string mensaje = queryType + Username1TextBox.Text;
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                Console.WriteLine("Mensaje enviado al servidor: " + mensaje);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al enviar la consulta: " + ex.Message);
            }
        }


        /*private void ActualizarListaUsuarios()
        {
            if (this.conectado == 1 && this.login == 1)
            {
                try
                {
                    byte[] buffer = new byte[1024];
                    int bytesRecibidos = server.Receive(buffer);
                    string respuesta = Encoding.ASCII.GetString(buffer, 0, bytesRecibidos);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al obtener la lista de usuarios conectados: " + ex.Message);
                }
            }
        }*/

        private void button3_Click_1(object sender, EventArgs e)
        {
            SendQuery("1/");
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            SendQuery("2/");
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            SendQuery("3/");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonInvitar_Click(object sender, EventArgs e)
        {
            if (listBoxUsuarios.SelectedItem != null)
            {
                string usuarioInvitado = listBoxUsuarios.SelectedItem.ToString();
                string mensaje = $"4/{Username1TextBox.Text}/{usuarioInvitado}";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                MessageBox.Show($"Has enviado una invitación a {usuarioInvitado}.");
            }
            else
            {
                MessageBox.Show("Debes seleccionar un usuario conectado.");
            }
        }

    }

}



